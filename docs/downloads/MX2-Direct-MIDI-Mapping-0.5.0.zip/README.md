# MX2 Direct MIDI mapping

This package is for using a Traktor MX2 with djay Pro **without MX2 Companion**.

## Install

1. Switch the MX2 to MIDI mode. Press both physical SHIFT buttons together once if needed.
2. Open `Traktor MX2 - Direct MIDI.djayMidiMapping` and confirm the import in djay.
3. In djay's MIDI settings, select the **Traktor MX2** device and the **Traktor MX2 - Direct MIDI** configuration. Do not select `MX2 for djay`, which is the virtual device used by Companion.
4. Stop Companion or any older MX2 bridge, and deselect older MX2 mappings to avoid duplicate commands.
5. Set the MX2 audio outputs in djay: main on channels 1–2, headphones on 3–4.

The mapping contains 105 actions using the physical MIDI addresses measured on the MX2. It covers both decks' main transport and jog controls, mixer and EQ, library navigation, and the default hotcue pad layer.

## Limits

Companion normally handles the SHIFT layer, four pad banks, channel FX selection, value calibration, RGB lights and meters. A djay mapping file alone cannot reproduce those stateful functions. This direct mapping omits MIDI output feedback, so button lights and meters are not controlled by djay through this file.

The mapping file passes structural checks, but this exact direct configuration has not yet been tested with the controller and djay. Start with paused tracks and moderate volume, and check Play, Cue, jog release and headphone preview on both decks before a session.

The 293-action `Visual Complete` file included with Companion targets its virtual `MX2 for djay` device. It is not the direct MIDI mapping.
